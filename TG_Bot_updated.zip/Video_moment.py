import cv2
from Garbage import *

def extract_frames(video_path):
    # Загрузка видео
    cap = cv2.VideoCapture(video_path)
    frames = []

    # Получение параметров видео
    fps = cap.get(cv2.CAP_PROP_FPS)
    frame_width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    frame_height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    size = (frame_width, frame_height)
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')  # Используйте 'mp4v' для MP4

    while True:
        ret, frame = cap.read()
        if not ret:
            break
        # Здесь можно вызвать вашу функцию обработки кадра
        _, processed_frame = get_results_photo2(frame)
        frames.append(processed_frame)

    cap.release()
    return frames, fps, size, fourcc


def save_video(frames, output_path, fps, size, fourcc):
    # Создание объекта VideoWriter
    out = cv2.VideoWriter(output_path, fourcc, fps, size)

    for frame in frames:
        out.write(frame)

    out.release()
