import telebot
from telebot import types
import cv2
from Garbage import get_results_photo2
from Video_moment import extract_frames,save_video


token = "7084278045:AAF2Nc-mLlUz-Noz-9l6DtlA-GhwV9WhhIg"
bot = telebot.TeleBot(token)

@bot.message_handler(commands=["start"])
def start(message):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    btn1 = types.KeyboardButton("Поменять фото")
    btn2 = types.KeyboardButton("Результат фото")
    btn3 = types.KeyboardButton("Поменять видео")
    btn4 = types.KeyboardButton("Результат видео")
    markup.add(btn1,btn3, btn2, btn4)
    bot.send_message(message.chat.id, text="Привет, {0.first_name}! Жду от тебя фото или видео qr-кода :) ".format(message.from_user),reply_markup=markup)

@bot.message_handler(content_types=['photo'])
def handle_photo(message):
    photo = message.photo[-1]
    file_info = bot.get_file(photo.file_id)
    downloaded_file = bot.download_file(file_info.file_path)
    save_path = 'photo.jpg'
    with open(save_path, 'wb') as new_file:
        new_file.write(downloaded_file)
    bot.reply_to(message, 'Фотография сохранена ')

@bot.message_handler(content_types=['video'])
def send_text(message):
    file_info = bot.get_file(message.video.file_id)
    downloaded_file = bot.download_file(file_info.file_path)
    save_path = 'video.mp4'
    with open(save_path, 'wb') as new_file:
        new_file.write(downloaded_file)
    bot.reply_to(message, "Видео сохранено")

@bot.message_handler(content_types=['text'])
def result(message):
    if message.text == "Поменять фото":
        bot.send_message(message.chat.id, text="Жду от тебя фото qr-кода :) ")
        @bot.message_handler(content_types=['photo'])
        def handle_photo(message):
            photo = message.photo[-1]
            file_info = bot.get_file(photo.file_id)
            downloaded_file = bot.download_file(file_info.file_path)
            save_path = 'photo.jpg'
            with open(save_path, 'wb') as new_file:
                new_file.write(downloaded_file)
            bot.reply_to(message, 'Фотография сохранена ')

    elif message.text == "Поменять видео":
        bot.send_message(message.chat.id, text="Жду от тебя видео qr-кода :) ")
        @bot.message_handler(content_types=['video'])
        def send_text(message):
            file_info = bot.get_file(message.video.file_id)
            downloaded_file = bot.download_file(file_info.file_path)
            save_path = 'video.mp4'
            with open(save_path, 'wb') as new_file:
                new_file.write(downloaded_file)
            bot.reply_to(message, "Видео сохранено")
    elif message.text == "Результат видео":
        video_path = 'video.mp4'
        frames, fps, size, fourcc = extract_frames(video_path)
        output_path = '9999.mp4'
        save_video(frames, output_path, fps, size, fourcc)
        video = open('9999.mp4', 'rb')
        bot.send_video(message.chat.id, video)
    else:
        answers, img = get_results_photo2(cv2.imread("photo.jpg"))  # Получение итогового изображения и ответов
        height, width = img.shape[:2]
        img = cv2.resize(img, (width // 2, height // 2), interpolation=cv2.INTER_AREA)
        cv2.imwrite('image_to_show.jpg', img)
        img_to_show = open('image_to_show.jpg', 'rb')
        bot.send_photo(message.chat.id, img_to_show)
        bot.send_message(message.chat.id, str(answers[:]))


bot.polling()