from ultralytics import YOLO
import cv2

model = YOLO('best.pt')
def update_image():

    img = cv2.imread('photo.jpg')
    print(img.shape)
    results = model(img, imgsz=640, conf=0.6, verbose=True)
    annotated_frame = results[0].plot()
    cv2.imwrite('annotated_frame.jpg', annotated_frame)
