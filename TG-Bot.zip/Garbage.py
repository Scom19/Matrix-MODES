from ultralytics import YOLO
import matplotlib.pyplot as plt
import cv2
import torch
import numpy as np
import json
from image_recognition import *

model = YOLO('best.pt')


# Трансформация карточек
def order_points(pts):
    rect = np.zeros((4, 2), dtype="float32")
    s = pts.sum(axis=1)
    rect[0] = pts[np.argmin(s)]
    rect[2] = pts[np.argmax(s)]
    diff = np.diff(pts, axis=1)
    rect[1] = pts[np.argmin(diff)]
    rect[3] = pts[np.argmax(diff)]
    return rect


def four_point_transform(image, pts):
    rect = order_points(pts)
    (tl, tr, br, bl) = rect

    widthA = np.sqrt(((br[0] - bl[0]) ** 2) + ((br[1] - bl[1]) ** 2))
    widthB = np.sqrt(((tr[0] - tl[0]) ** 2) + ((tr[1] - tl[1]) ** 2))
    maxWidth = max(int(widthA), int(widthB))

    heightA = np.sqrt(((tr[0] - br[0]) ** 2) + ((tr[1] - br[1]) ** 2))
    heightB = np.sqrt(((tl[0] - bl[0]) ** 2) + ((tl[1] - bl[1]) ** 2))
    maxHeight = max(int(heightA), int(heightB))
    dst = np.array([
        [0, 0],
        [maxWidth - 1, 0],
        [maxWidth - 1, maxHeight - 1],
        [0, maxHeight - 1]], dtype="float32")
    M = cv2.getPerspectiveTransform(rect, dst)
    warped = cv2.warpPerspective(image, M, (maxWidth, maxHeight))
    return warped


# поиск "крайних точек" карточки
def find_largest_contour(image):
    # Переводим изображение в оттенки серого
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    # Применяем пороговую обработку для получения бинарного изображения
    _, thresh = cv2.threshold(gray, 127, 255, 0)
    # Инвертируем бинарное изображение
    thresh = cv2.bitwise_not(thresh)
    # Находим контуры на инвертированном бинарном изображении
    contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    # Находим наибольший контур
    largest_contour = max(contours, key=cv2.contourArea)
    extreme_points = [(0, 0), (0, image.shape[0]), (image.shape[1], image.shape[0]),
                      (image.shape[1], 0)]  # Изначально углы изображения
    min_distances = [np.inf, np.inf, np.inf, np.inf]  # Изначально расстояния до углов
    # Перебор всех точек контура для поиска крайних
    for point in largest_contour:
        x, y = point[0][0], point[0][1]
        distances = [x, image.shape[0] - y, image.shape[1] - x, y]
        for i in range(4):
            if distances[i] < min_distances[i]:
                min_distances[i] = distances[i]
                extreme_points[i] = (x, y)
    return extreme_points


# функция вырезки карточек из изображения
def crop_images(img, coordinates):
    images = []
    # Применяем пороговую обработку для получения бинарного изображения
    for coords in coordinates:
        left, top, right, bottom = map(int, coords)
        cropped_img = img[top:bottom, left:right]
        images.append(cropped_img)
    return images


# функция поворота карточи на угол angle
def rotate_image(image, angle):
    # Получаем высоту и ширину изображения
    height, width = image.shape[:2]
    # Вычисляем центр поворота
    center = (width / 2, height / 2)
    # Поворачиваем изображение на заданный угол
    rotation_matrix = cv2.getRotationMatrix2D(center, angle, 1.0)
    rotated_image = cv2.warpAffine(image, rotation_matrix, (width, height))
    return rotated_image


def get_results_photo(img):
    answers = []
    results = model(img)
    boxes = results[0].boxes.xyxy.cpu().tolist()
    images = crop_images(img, boxes)
    for i in range(len(images)):
        image = images[i]
        image = cv2.copyMakeBorder(image, 10, 10, 10, 10, cv2.BORDER_CONSTANT, value=[255, 255, 255])
        image = rotate_image(image, 30)
        pts = np.array(find_largest_contour(image), dtype="float32")
        warped = four_point_transform(image, pts)
        gray_image = cv2.cvtColor(warped, cv2.COLOR_BGR2GRAY)
        count = 0
        while mainer(gray_image, 'image_database.json') == None and count <= 2:
            image = rotate_image(image, -60)
            pts = np.array(find_largest_contour(image), dtype="float32")
            warped = four_point_transform(image, pts)
            gray_image = cv2.cvtColor(warped, cv2.COLOR_BGR2GRAY)
            count += 1
        answers.append(mainer(gray_image, 'image_database.json'))
    return answers
