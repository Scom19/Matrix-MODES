import telebot
from telebot import types

import Garbage
from Send_photo import *
from Garbage import *


token = "7084278045:AAF2Nc-mLlUz-Noz-9l6DtlA-GhwV9WhhIg"
bot = telebot.TeleBot(token)

@bot.message_handler(commands=["start"])
def start(message):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    btn1 = types.KeyboardButton("Поменять фото")
    btn2 = types.KeyboardButton("Результат")
    markup.add(btn1, btn2)
    bot.send_message(message.chat.id, text="Привет, {0.first_name}! Жду от тебя фото qr-кода :) ".format(message.from_user),reply_markup=markup)

@bot.message_handler(content_types=['photo'])
def handle_photo(message):
    photo = message.photo[-1]
    file_info = bot.get_file(photo.file_id)
    downloaded_file = bot.download_file(file_info.file_path)
    save_path = 'photo.jpg'
    with open(save_path, 'wb') as new_file:
        new_file.write(downloaded_file)
    bot.reply_to(message, 'Фотография сохранена ')

@bot.message_handler(content_types=['text'])
def result(message):
    if message.text == "Поменять фото":
        bot.send_message(message.chat.id, text="Жду от тебя фото qr-кода :) ")
        @bot.message_handler(content_types=['photo'])
        def handle_photo(message):
            photo = message.photo[-1]
            file_info = bot.get_file(photo.file_id)
            downloaded_file = bot.download_file(file_info.file_path)
            save_path = 'photo.jpg'
            with open(save_path, 'wb') as new_file:
                new_file.write(downloaded_file)
            bot.reply_to(message, 'Фотография сохранена ')
    else:
        update_image()
        photo_2 = open('annotated_frame.jpg', 'rb')
        bot.send_photo(message.chat.id, photo_2)
        bot.send_message(message.chat.id, str(Garbage.get_results_photo(cv2.imread("photo.jpg")))[1:-1])


bot.polling()